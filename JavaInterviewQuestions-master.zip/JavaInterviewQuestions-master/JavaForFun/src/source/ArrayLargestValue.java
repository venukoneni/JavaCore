package source;

public class ArrayLargestValue {
	static int i, res, max, a[];

	static int max(int a[]) {
		max = 0;
		for (i = 0; i < a.length; i++) {
			if (a[i] >= a[max]) {
				max = i;
			}

		}
		return (a[max]);
	}

	public static void main(String args[]) {
		res = ArrayLargestValue.max(new int[] { 173, 29, 391, 41 });
		System.out.println("Largest value in the given array is  : " + res);
	}

}